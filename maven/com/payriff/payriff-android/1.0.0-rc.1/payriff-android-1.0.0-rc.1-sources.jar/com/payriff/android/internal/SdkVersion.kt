package com.payriff.android.internal

/** Version of the Payriff Android SDK. Generated from VERSION_NAME in gradle.properties. */
internal const val SDK_VERSION: String = "1.0.0-rc.1"
