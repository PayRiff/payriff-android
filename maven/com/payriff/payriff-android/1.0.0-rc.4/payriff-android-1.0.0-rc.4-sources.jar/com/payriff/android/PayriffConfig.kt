package com.payriff.android

import com.payriff.android.internal.card.ClientApiHosts

/**
 * SDK configuration, passed to [Payriff.configure].
 *
 * Kotlin uses named arguments; Java uses [Builder]:
 * ```
 * Payriff.configure(
 *     PayriffConfig(
 *         publishableKey = "pr_pk_live_…",
 *         environment = PayriffEnvironment.SANDBOX,
 *         region = PayriffRegion.AZ,
 *     ),
 * )
 * ```
 *
 * Creating a configuration never throws. A [publishableKey] that is missing, or is not a publishable key
 * (`pr_pk_live_…`), makes every card call fail with [PayriffErrorCode.INVALID_CONFIG]. The secret key never belongs in
 * the app: your server creates orders with it and gives the app each order's `orderId` and `clientSecret`.
 *
 * @param publishableKey Your publishable key. See [PayriffConfig.publishableKey].
 * @property environment [PayriffEnvironment.PRODUCTION] (default) or [PayriffEnvironment.SANDBOX]. With [region] it
 *   selects the API host of every card call, [apiBaseUrl].
 * @property region [PayriffRegion.AZ] (default, `api.payriff.com`) or [PayriffRegion.SA] (Saudi Arabia, GCC Pay,
 *   `api.gccpay.sa`). With [environment] it selects the API host of every card call, [apiBaseUrl]. [PayriffRegion.SA]
 *   has no sandbox: with [PayriffEnvironment.SANDBOX] its card payments go to production and charge real cards.
 * @property language Language of the card form and the 3-D Secure sheet. `null` uses the device language.
 * @property enableLogging Send SDK logs to Logcat and [PayriffLogger.listener]. Defaults to `false`.
 * @property allowScreenCaptureInDebug Debug builds only: lets screenshots and screen recordings capture the card form
 *   and the 3-D Secure sheet, for example for QA. They are otherwise protected with `FLAG_SECURE`. Release builds ignore
 *   it and always protect them. Defaults to `false`.
 * @property allowCompromisedDevices Debug builds only: lets card payments run on a rooted device, when a hooking
 *   framework is detected, or when the check cannot complete ([Payriff.isDeviceCompromised], CONTRACT §16.16), with a
 *   warning, for development on rooted or hooked test devices. Otherwise they are refused with
 *   [PayriffErrorCode.DEVICE_COMPROMISED]. Only a debuggable app (`ApplicationInfo.FLAG_DEBUGGABLE`) may opt out:
 *   release builds ignore it, with a warning, and refuse such devices, so leaving it on cannot reach production.
 *   Defaults to `false`.
 * @property googlePay Google Pay in [PayriffPaymentView] and [PayriffGooglePayButton] (CONTRACT §17): your
 *   [PayriffGooglePayConfig]. `null` (the default): Google Pay is never offered. It is offered for an order that lists
 *   `GOOGLE_PAY` with its gateway, on a device that is not compromised and can pay with Google Pay. The Google Pay
 *   environment is `TEST` with the sandbox host (`https://sb-api.payriff.com`) and `PRODUCTION` otherwise.
 * @property strings Your own texts for every screen of the SDK (CONTRACT §18.6): the card form, [PayriffPaymentView]
 *   and the 3-D Secure sheet, also the one [PayriffCardPaymentLauncher] opens. `null` (the default) keeps the built-in
 *   texts in [language]. [PayriffPaymentView.strings] wins over it in that view and the sheets it opens. It is not part
 *   of [toString].
 */
public class PayriffConfig(
    publishableKey: String? = null,
    public val environment: PayriffEnvironment = PayriffEnvironment.PRODUCTION,
    public val region: PayriffRegion = PayriffRegion.AZ,
    public val language: PayriffLanguage? = null,
    public val enableLogging: Boolean = false,
    public val allowScreenCaptureInDebug: Boolean = false,
    public val allowCompromisedDevices: Boolean = false,
    public val googlePay: PayriffGooglePayConfig? = null,
    public val strings: PayriffStrings? = null,
) {
    /**
     * Publishable key (`pr_pk_live_…`) of the card flow ([PayriffCardForm], [PayriffCardPaymentLauncher],
     * [Payriff.retrieveOrder]), trimmed; blank means `null`. It is safe to ship in the app. A key that does not start
     * with `pr_pk_live_` (a secret key, for example) makes card calls fail with [PayriffErrorCode.INVALID_CONFIG].
     */
    public val publishableKey: String? = publishableKey?.trim()?.takeIf { it.isNotEmpty() }

    /**
     * API base URL of [region] and [environment], the host of every card call (CONTRACT §16.2):
     *
     * | [region] | [environment] | API base URL |
     * |---|---|---|
     * | [PayriffRegion.AZ] | [PayriffEnvironment.PRODUCTION] | `https://api.payriff.com` |
     * | [PayriffRegion.AZ] | [PayriffEnvironment.SANDBOX] | `https://sb-api.payriff.com` (provisional) |
     * | [PayriffRegion.SA] | [PayriffEnvironment.PRODUCTION] | `https://api.gccpay.sa` |
     * | [PayriffRegion.SA] | [PayriffEnvironment.SANDBOX] | `https://api.gccpay.sa`: there is no Saudi sandbox |
     */
    public val apiBaseUrl: String
        get() = ClientApiHosts.of(region, environment)

    /** Returns a [Builder] pre-filled with this configuration. */
    public fun newBuilder(): Builder = Builder()
        .publishableKey(publishableKey)
        .environment(environment)
        .region(region)
        .language(language)
        .enableLogging(enableLogging)
        .allowScreenCaptureInDebug(allowScreenCaptureInDebug)
        .allowCompromisedDevices(allowCompromisedDevices)
        .googlePay(googlePay)
        .strings(strings)

    /**
     * Describes the configuration with the publishable key redacted as `pr_pk_live_***(<length>)`, so it is safe to log.
     * Google Pay shows as `googlePay=on` or `googlePay=off` (CONTRACT §17.2).
     */
    override fun toString(): String =
        "PayriffConfig(publishableKey=${publishableKey?.let(::redactPublishableKey)}, environment=$environment, " +
            "region=$region, language=$language, enableLogging=$enableLogging, allowScreenCaptureInDebug=$allowScreenCaptureInDebug, " +
            "allowCompromisedDevices=$allowCompromisedDevices, googlePay=${if (googlePay != null) "on" else "off"})"

    /** Java-friendly builder for [PayriffConfig]. Every setter mirrors the constructor parameter of the same name. */
    public class Builder {
        private var publishableKey: String? = null
        private var environment: PayriffEnvironment = PayriffEnvironment.PRODUCTION
        private var region: PayriffRegion = PayriffRegion.AZ
        private var language: PayriffLanguage? = null
        private var enableLogging: Boolean = false
        private var allowScreenCaptureInDebug: Boolean = false
        private var allowCompromisedDevices: Boolean = false
        private var googlePay: PayriffGooglePayConfig? = null
        private var strings: PayriffStrings? = null

        /** Sets [PayriffConfig.publishableKey]. */
        public fun publishableKey(value: String?): Builder = apply { publishableKey = value }

        /** Sets [PayriffConfig.environment]. */
        public fun environment(value: PayriffEnvironment): Builder = apply { environment = value }

        /** Sets [PayriffConfig.region]. */
        public fun region(value: PayriffRegion): Builder = apply { region = value }

        /** Sets [PayriffConfig.language]. */
        public fun language(value: PayriffLanguage?): Builder = apply { language = value }

        /** Sets [PayriffConfig.enableLogging]. */
        public fun enableLogging(value: Boolean): Builder = apply { enableLogging = value }

        /** Sets [PayriffConfig.allowScreenCaptureInDebug]. Debug builds only. */
        public fun allowScreenCaptureInDebug(value: Boolean): Builder = apply { allowScreenCaptureInDebug = value }

        /** Sets [PayriffConfig.allowCompromisedDevices]. Debug builds only. */
        public fun allowCompromisedDevices(value: Boolean): Builder = apply { allowCompromisedDevices = value }

        /** Sets [PayriffConfig.googlePay]; `null` turns Google Pay off. */
        public fun googlePay(value: PayriffGooglePayConfig?): Builder = apply { googlePay = value }

        /** Sets [PayriffConfig.strings]; `null` keeps the built-in texts. */
        public fun strings(value: PayriffStrings?): Builder = apply { strings = value }

        /** Creates the configuration. Never throws; see [PayriffConfig] for validation. */
        public fun build(): PayriffConfig = PayriffConfig(
            publishableKey = publishableKey,
            environment = environment,
            region = region,
            language = language,
            enableLogging = enableLogging,
            allowScreenCaptureInDebug = allowScreenCaptureInDebug,
            allowCompromisedDevices = allowCompromisedDevices,
            googlePay = googlePay,
            strings = strings,
        )
    }

    private companion object {
        private const val PUBLISHABLE_PREFIX = "pr_pk_live_"

        /** `pr_pk_live_***(<length>)` for a well-formed key, otherwise `***(<length>)`: never the key itself. */
        private fun redactPublishableKey(key: String): String =
            if (key.startsWith(PUBLISHABLE_PREFIX)) "$PUBLISHABLE_PREFIX***(${key.length})" else "***(${key.length})"
    }
}
